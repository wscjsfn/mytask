<html>
	<head>
		<meta charset="utf-8" />
		<title>用户&nbsp;注册</title>
		<link rel="stylesheet" type="text/css" href="./01.css" />
	</head>
	<body>
		<div id="box1">
			<div id="box6">WscJsfn
			</div>
		</div>
		<div class="clear"></div>
		<div id="box2">
			<div id="box4">用户&nbsp;注册</div>
			<form action="./02.php" method="post">
				<div id="box5">				
					<span>用户名:</span><br /><input id="btn4" class="circle-btn" required="required" placeholder="" /><br />
					<span>密&nbsp;&nbsp;码:</span><br /><input id="btn5" class="circle-btn" required="required" placeholder=""/><br />
					<span>邮&nbsp;&nbsp;箱</span><br /><input id="btn6" class="circle-btn"required="required" placeholder="" /><br />					
					<span>验证码:</span><br />
						<input id="btn7" class="circle-btn1" name="code"/>
						<img id="code" src="./code.php" class="circle-btn1">
				</div>
				<div id="box8">
					<button type="submit" id="btn3" name="some-name">注&nbsp;&nbsp;册</button>
				</div>
			</form>
		</div>
		<div class="clear"></div>
		<div id="box3">
			<h5>Copyright ? 2016, WscJsfn Digital Co., Ltd. All Rights Reserved.</h5>
		</div>
	</body>
	<script type="text/javascript" src="./01.js"></script>
</html>